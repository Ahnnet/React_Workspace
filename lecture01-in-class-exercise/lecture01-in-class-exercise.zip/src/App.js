import logo from './logo.svg';
import './App.css';
import Car from './Car';

function App() {
  return (
    <div>
      <Car/>
    </div>
  );
}

export default App;
